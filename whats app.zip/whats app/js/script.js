$(document).ready(function(){
	$("#menu-icon").click(function(e){
		if($("#menu-box").is(":hidden")){
			$("#menu-box").show();
		} else{
			$("#menu-box").hide();
		}
		e.stopPropagation();
		});
	$("body").click(function(event){
		//alert("sfd")
		if($("#menu-box").is(":visible")){
			$("#menu-box").hide();
		}
	})
});
	
$(document).ready(function(){	
$(".chat").contextmenu(function(){
		if($("#menu-box1").is(":hidden")){
			$("#menu-box1").show();
		} else{
			$("#menu-box1").hide();
		}
		$(document).bind("contextmenu",function(e) {
  e.preventDefault();
  
});
});
});
// $(document).ready(function(){
// 	$("#msg-icon").click(function(){
// 		if($(".message").is(":hidden")){
// 			$(".message").show();
// 		} else{
// 			$(".message").hide();
// 		}
// });
$(document).ready(function(){

	$(".msg-icon").click(function(){
		$(".message").animate({
			width:"toggle"
		});
	
});

	$(".arrow").click(function(){
		$(".message").animate({
			width:"toggle"
				});
	

});
});
$(document).ready(function(){
	$(".sta-icon").click(function(){
		$(".right-leftstatus").animate({
			width:"toggle"
		});
	
});

	$(".exit-icon").click(function(){
		$(".right-leftstatus").animate({
			width:"toggle"
				});
});
});
$(document).ready(function(){
	$(".header-image").click(function(){
		$(".profile").animate({
			width:"toggle"
		});
});
	$(".profile-arrow").click(function(){
		$(".profile").animate({
			width:"toggle"
		});
	});
});
$(document).ready(function(){
	$(".menu-setting").click(function(){
		$(".setting-log").animate({
			width:"toggle"
		});
});
	$(".setting-arrow").click(function(){
		$(".setting-log").animate({
			width:"toggle"
		});
	});
});

$(document).ready(function(){
	$("#menu-profile").click(function(){
		$(".profile").animate({
			width:"toggle"
		});
});
	$(".menu-profile-arrow").click(function(){
		$(".profile").animate({
			width:"toggle"
		});
	});
});
$(document).ready(function(){
	$("#menu-group").click(function(){
		$(".newgroup-log").animate({
			width:"toggle"
		});
	});
	$(".newgroup-arrow").click(function(){
		$(".newgroup-log").animate({
			width:"toggle"
		});
	});
});
